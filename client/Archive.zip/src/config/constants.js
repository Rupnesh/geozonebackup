export var constants = {   
    // host: 'http://192.168.1.112:8080/'
    host: 'http://192.168.1.94:8080/',  //node ip
    hostflask: 'http://192.168.1.212:6060/'  //flas ip
}