import { connect } from 'react-redux';

import BaseCordView from './BaseCordView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(BaseCordView);
