import { connect } from 'react-redux';

import SenzorsView from './SenzorsView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(SenzorsView);
