import { connect } from 'react-redux';

import RadiosView from './RadiosView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(RadiosView);
