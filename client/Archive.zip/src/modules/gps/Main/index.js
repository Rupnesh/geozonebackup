import { connect } from 'react-redux';

import MainView from './MainView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(MainView);
