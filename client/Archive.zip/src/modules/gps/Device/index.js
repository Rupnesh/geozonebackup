import { connect } from 'react-redux';

import DeviceView from './DeviceView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(DeviceView);
