import { connect } from 'react-redux';

import FirmwareView from './FirmwareView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(FirmwareView); 
