import { connect } from 'react-redux';

import BlueToothView from './CableView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(BlueToothView);
