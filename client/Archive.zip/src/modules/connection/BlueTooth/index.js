import { connect } from 'react-redux';

import BlueToothView from './BlueToothView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(BlueToothView);
