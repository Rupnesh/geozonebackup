import { connect } from 'react-redux';

import SurveyView from './SurveyView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(SurveyView);
