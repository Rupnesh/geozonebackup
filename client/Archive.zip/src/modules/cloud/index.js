import { connect } from 'react-redux';

import CloudView from './CloudView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(CloudView);
