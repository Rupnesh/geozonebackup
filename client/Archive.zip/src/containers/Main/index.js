import MainView from './MainView';

// to be connected to redux
export default MainView;
