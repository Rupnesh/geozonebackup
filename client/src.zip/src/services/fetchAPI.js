
import {constants} from '../config/constants'

// Fetches an API response and normalizes the result JSON according to schema.
// This makes every API response have the same shape, regardless of how nested it was.

var headers = {'Content-Type':'application/json'}
export const  GETAPI = (api) => {
  return fetch(constants.host + api)
    .then(res =>  res.json() )
    .then(data => {
      return data
    })
    .catch((error) => {
      console.log(error)
      return error;
    });  
}
export const  GETAPIFlask = (api) => {
  return fetch(constants.hostflask + api)
    .then(res =>  res.json() )
    .then(data => {
      return data
    })
    .catch((error) => {
      console.log(error)
      return error;
    });  
}

export const  POSTAPI = (api, data) => {
  return fetch(constants.host + api, {
    method: "POST", // *GET, POST, PUT, DELETE, etc.
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "*", 
      'Accept': 'application/json, text/plain, */*',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data), // body data type must match "Content-Type" header
  })
    .then(res =>  res.json() )
    .then(data => {
      return data
    })
    .catch((error) => {
      console.log(error)
      return error;
    });  
}




