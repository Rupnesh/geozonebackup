export var api = {   
    // node wifi api 
    GET_WIFI_LIST: 'v1/wifi/on',
    OFF_WIFI: 'v1/wifi/off',
    LOGIN_WITH_WIFI: 'v1/wifi/connect',

    //flask api's
    LOGGING_STATUS: 'api/v1/logging',
    MEMORY_STATUS: 'api/v1/logging/memory'

}



