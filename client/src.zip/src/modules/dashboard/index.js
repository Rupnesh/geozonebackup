import { connect } from 'react-redux';

import DashboardView from './DashboardView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(DashboardView);
