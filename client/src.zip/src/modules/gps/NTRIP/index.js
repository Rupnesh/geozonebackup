import { connect } from 'react-redux';

import NTRIPView from './NTRIPView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(NTRIPView);
