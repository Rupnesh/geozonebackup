import { connect } from 'react-redux';

import CalibrationView from './CalibrationView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(CalibrationView);
