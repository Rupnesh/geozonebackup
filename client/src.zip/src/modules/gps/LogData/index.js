import { connect } from 'react-redux';

import LogDataview from './LogDataview';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(LogDataview);
