import { connect } from 'react-redux';

import CollectionsView from './CollectionsView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(CollectionsView);
