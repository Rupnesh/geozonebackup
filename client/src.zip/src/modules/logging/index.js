import { connect } from 'react-redux';

import LoggingView from './LoggingView';

const mapStateToProps = (state) => {
    return {};
};

export default connect(mapStateToProps, {})(LoggingView); 
