module.exports = (verifyCode) => {

    return 'Your verificatin code is: ' + verifyCode;

};