/**
 * Created by mariuspotor on 18/10/16.
 */
const User = require('./User');

module.exports = {
  User,
};

