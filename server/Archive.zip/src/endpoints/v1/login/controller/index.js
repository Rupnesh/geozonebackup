const Login = require('./Login');

module.exports = {
  Login,
};
