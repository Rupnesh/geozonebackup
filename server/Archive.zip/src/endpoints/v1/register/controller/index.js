const Register = require('./Register');

module.exports = {
  Register,
};

