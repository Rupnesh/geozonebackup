module.exports = (error)=> {

  console.log("ERROR: ", error);
  
};
